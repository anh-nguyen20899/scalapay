export class BaseDTO {
  success: string;
  message: string;
}
