export const PROD_ENV = '';
export const DOMAIN = '';
export const DEV_DOMAIN = '';
export const DEV_API_SERVER = '';
export const MAIN_URL = '';
